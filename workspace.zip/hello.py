my_name = 'Song'

print("Hello " + my_name)